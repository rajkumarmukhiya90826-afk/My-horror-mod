package com.replica;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.animal.Cow;
import net.minecraft.world.entity.animal.Sheep;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.GlassBlock;
import net.minecraft.world.level.block.IronBarsBlock;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Replica. Extends Zombie for the zombie AI basics; the true form is drawn with ReplicaModel.
 * While disguised it is invisible and a sheep / cow / zombie "shell" stands in its place.
 */
public class ReplicaEntity extends Zombie {

    public enum Kind { SHEEP, COW, ZOMBIE }

    enum Phase { OBSERVE, CHASE }

    private static final String[] L_OBSERVE = {
            "Tum yahan akele ho na...?",
            "Mujhe lagta hai tum mujhe jaante ho.",
            "Peeche mat dekhna... koi hai.",
            "Kitni shaant jagah hai... hai na?",
            "Tumhari saansein tez chal rahi hain...",
            "Maine tumhe kal raat bhi dekha tha.",
    };
    private static final String[] L_FEAR = {
            "Tumhe {f} se darr lagta hai... main mehsoos kar sakta hoon.",
            "Darr ki khushbu aa rahi hai... {f}... haan?",
    };
    private static final String[] L_ATTACK = {
            "Tumne mujhe pehchan liya...",
            "Maine tumhara darr kha liya hai ({f}). Ab khel shuru.",
    };
    private static final String[] L_CHASE = {
            "Bhaag lo... main tumhare saath hi hoon.",
            "Aasman mein bhi nahi bachoge.",
            "Maine kaha tha... peeche mat dekhna.",
            "Tumhari dhadkan sun raha hoon...",
            "{f}... yaad hai? Ab wahi tumhari maut hai.",
    };
    private static final String[] L_HIT = { "Mil gaye...", "Bas ek aur...", "Dard? Ye to shuruaat hai." };
    private static final String[] L_GIVEUP = { "Aaj nahi... par main wapas aaunga." };

    private ServerPlayer victim;
    private Mob shell;
    private String displayName = "Villager";
    private Phase phase = Phase.OBSERVE;

    private int observeEnd;
    private int nextAct;
    private int actEnd;
    private String act;
    private float actYaw;
    private int spotted;
    private int nextLine;
    private int nextSound;
    private int nextMusic;
    private int nextFear;
    private int chaseEnd;
    private int lastHit;
    private int nextScream;

    // window peeking: when the player is indoors he stands outside a window and watches
    private BlockPos peekPos;
    private int peekUntil;
    private int nextPeek;
    private int slinkUntil;
    private double slinkX;
    private double slinkZ;

    private final Map<String, Integer> fear = new HashMap<>();

    public ReplicaEntity(EntityType<? extends Zombie> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Zombie.createAttributes()
                .add(Attributes.MAX_HEALTH, 400.0)
                .add(Attributes.MOVEMENT_SPEED, 0.25)
                .add(Attributes.FOLLOW_RANGE, 48.0)
                .add(Attributes.ATTACK_DAMAGE, 3.0);
    }

    /** Only float. Movement and attacks are driven from tick(), so vanilla zombie AI does not fight the logic. */
    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
    }

    // ------------------------------------------------------------- setup
    void begin(ServerPlayer target, Kind kind, String name) {
        this.victim = target;
        this.displayName = name;
        this.setPersistenceRequired();
        this.setInvisible(true);
        this.setCustomNameVisible(false);

        ServerLevel sl = (ServerLevel) this.getCommandSenderWorld();
        this.shell = switch (kind) {
            case SHEEP -> new Sheep(EntityType.SHEEP, sl);
            case COW -> new Cow(EntityType.COW, sl);
            case ZOMBIE -> new Zombie(EntityType.ZOMBIE, sl);
        };
        shell.setNoAi(true);
        shell.setPersistenceRequired();
        shell.setCustomName(Component.literal(name));
        shell.setCustomNameVisible(true);
        shell.moveTo(getX(), getY(), getZ(), getYRot(), 0F);
        sl.addFreshEntity(shell);
        ReplicaMod.SHELLS.put(shell.getUUID(), this);

        int now = tickCount;
        observeEnd = now + ThreadLocalRandom.current().nextInt(3 * 60 * 20, 5 * 60 * 20 + 1);
        nextAct = now + rand(300, 700);
        nextLine = now + rand(300, 600);
        nextSound = now + rand(250, 600);
        nextMusic = now;
        nextFear = now + rand(400, 600);
        nextPeek = now + rand(200, 400);
        lastHit = 0;

        victim.playNotifySound(ReplicaMod.AMBIENT.get(), SoundSource.MUSIC, 0.5F, 1F);
        say(pick(L_OBSERVE));
    }

    // ------------------------------------------------------------- tick
    @Override
    public void tick() {
        super.tick();
        if (this.getCommandSenderWorld().isClientSide) return;

        setRemainingFireTicks(0); // no sun burn: he is not a zombie in daylight
        if (victim == null || !victim.isAlive() || victim.isRemoved()) {
            discard();
            return;
        }
        if (victim.getCommandSenderWorld() != this.getCommandSenderWorld()) {
            discard();
            return;
        }
        if (shell != null && !shell.isRemoved()) {
            shell.moveTo(getX(), getY(), getZ(), getYRot(), 0F);
            shell.setYHeadRot(getYHeadRot());
        }

        if (phase == Phase.OBSERVE) observeTick();
        else chaseTick();
    }

    private void observeTick() {
        int now = tickCount;

        if (now % 20 == 0) sampleFear();
        if (now >= observeEnd) {
            reveal();
            return;
        }

        if (peekTick(now)) {
            fearAndSounds(now);
            return;
        }

        // the "slips": head flips round, twitches, or stares. Not looking at him = not seen.
        if (act != null) {
            if (lookingAtMe()) spotted += 2;
            else spotted = Math.max(0, spotted - 1);
            if (spotted >= 20) {
                reveal();
                return;
            }
            if (now >= actEnd) {
                act = null;
                nextAct = now + rand(500, 1300);
            } else if (act.equals("flip")) {
                setYRot(actYaw + 180F);
            } else if (act.equals("twitch")) {
                setYRot(actYaw + rand(-110, 110));
            }
        } else if (now >= nextAct) {
            String[] kinds = {"flip", "twitch", "stare", "flip"};
            act = kinds[ThreadLocalRandom.current().nextInt(kinds.length)];
            actYaw = getYRot();
            actEnd = now + (act.equals("stare") ? 70 : act.equals("twitch") ? 26 : 36);
            spotted = 0;
        }

        // walk around calmly at 9 to 14 blocks. He never runs away from being looked at.
        double dx = victim.getX() - getX();
        double dz = victim.getZ() - getZ();
        double d = Math.sqrt(dx * dx + dz * dz);
        if (d > 14) {
            getNavigation().moveTo(victim.getX(), victim.getY(), victim.getZ(), 0.6);
        } else if (d < 9) {
            getNavigation().moveTo(getX() - dx * 0.6, getY(), getZ() - dz * 0.6, 0.6);
        } else {
            getNavigation().stop();
        }
        getLookControl().setLookAt(victim, 30F, 30F);
        fearAndSounds(now);
    }

    /** Ambient track, stare sounds, lines. Shared by the walking and the peeking observe states. */
    private void fearAndSounds(int now) {
        if (now >= nextMusic) {
            nextMusic = now + 400; // the ambient track is about 20 seconds
            victim.playNotifySound(ReplicaMod.AMBIENT.get(), SoundSource.MUSIC, 0.5F, 1F);
        }
        if (now >= nextSound) {
            nextSound = now + rand(300, 800);
            victim.playNotifySound(SoundEvents.ENDERMAN_STARE, SoundSource.HOSTILE, rnd(0.5F, 1F), rnd(0.5F, 0.9F));
        }
        if (now >= nextLine) {
            nextLine = now + rand(700, 1500);
            say(pick(L_OBSERVE));
        }
        if (now >= nextFear && !fear.isEmpty()) {
            nextFear = now + rand(1800, 3000);
            say(pick(L_FEAR).replace("{f}", fearName()));
        }
    }

    /**
     * Window peeking. If the player is indoors and there is a glass pane or iron bars block
     * within 6 blocks, he walks to the outside of that window and stands there watching.
     * If the player looks at him, he slinks away into the dark instead of attacking.
     * Returns true when this tick was spent peeking or slinking.
     */
    private boolean peekTick(int now) {
        if (now < slinkUntil) {
            getNavigation().moveTo(slinkX, getY(), slinkZ, 0.7);
            return true;
        }

        if (peekPos != null) {
            if (lookingAtMe()) {
                // seen through the glass: slink off 18 blocks away, no attack
                peekPos = null;
                nextPeek = now + rand(2400, 4000);
                Vec3 away = position().subtract(victim.position());
                Vec3 dir = away.lengthSqr() < 0.01 ? new Vec3(1, 0, 0) : away.normalize();
                slinkX = getX() + dir.x * 18;
                slinkZ = getZ() + dir.z * 18;
                slinkUntil = now + 240;
                return true;
            }
            if (now >= peekUntil) {
                peekPos = null;
                nextPeek = now + rand(2400, 4000);
                return false;
            }
            if (distanceToSqr(peekPos.getX() + 0.5, peekPos.getY(), peekPos.getZ() + 0.5) > 1.0) {
                getNavigation().moveTo(peekPos.getX() + 0.5, peekPos.getY(), peekPos.getZ() + 0.5, 0.5);
            } else {
                getNavigation().stop();
            }
            getLookControl().setLookAt(victim, 30F, 30F);
            return true;
        }

        if (now >= nextPeek && !this.getCommandSenderWorld().canSeeSky(victim.blockPosition())) {
            BlockPos spot = findPeekSpot();
            if (spot != null) {
                peekPos = spot;
                peekUntil = now + rand(400, 900);
            }
            nextPeek = now + (spot != null ? rand(1200, 2000) : 200);
        }
        return false;
    }

    /** A free, outdoor spot just outside a glass pane or iron bars block near the player. */
    private BlockPos findPeekSpot() {
        Level lvl = this.getCommandSenderWorld();
        BlockPos base = victim.blockPosition();
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        for (int dx = -6; dx <= 6; dx++) {
            for (int dy = -2; dy <= 2; dy++) {
                for (int dz = -6; dz <= 6; dz++) {
                    BlockPos w = base.offset(dx, dy, dz);
                    Block b = lvl.getBlockState(w).getBlock();
                    if (!(b instanceof GlassBlock || b instanceof IronBarsBlock)) continue;
                    // the outside is the side of the window facing away from the player
                    int ox = 0;
                    int oz = 0;
                    if (Math.abs(dx) >= Math.abs(dz)) ox = Integer.signum(dx);
                    else oz = Integer.signum(dz);
                    if (ox == 0 && oz == 0) continue;
                    BlockPos spot = w.offset(ox, 0, oz);
                    if (!lvl.getBlockState(spot).isAir()) continue;
                    if (!lvl.getBlockState(spot.above()).isAir()) continue;
                    if (!lvl.getBlockState(spot.below()).isSolid()) continue;
                    if (!lvl.canSeeSky(spot)) continue;
                    double dist = spot.distSqr(base);
                    if (dist < bestDist) {
                        bestDist = dist;
                        best = spot;
                    }
                }
            }
        }
        return best;
    }

    private void chaseTick() {
        int now = tickCount;
        if (now >= chaseEnd) {
            say(pick(L_GIVEUP));
            discard();
            return;
        }

        if (now >= nextMusic) {
            nextMusic = now + 320; // the chase track is 16 seconds long
            victim.playNotifySound(ReplicaMod.CHASE.get(), SoundSource.MUSIC, 0.9F, 1F);
        }
        if (now >= nextScream) {
            nextScream = now + rand(100, 200);
            victim.playNotifySound(SoundEvents.ENDERMAN_SCREAM, SoundSource.HOSTILE, rnd(0.6F, 1.1F), rnd(0.5F, 0.9F));
        }
        if (now >= nextLine) {
            nextLine = now + rand(300, 600);
            say(pick(L_CHASE).replace("{f}", fearName()));
        }

        double d = distanceTo(victim);

        if (victim.isFallFlying() && d > 3) {
            // follow the elytra flight through the air
            Vec3 dir = victim.position().subtract(position()).normalize().scale(1.1);
            moveTo(getX() + dir.x, getY() + dir.y, getZ() + dir.z, getYRot(), getXRot());
        } else if (d > 2.2) {
            getNavigation().moveTo(victim, 1.3);
        } else {
            getNavigation().stop();
        }

        // too far away: reappear behind the player
        if (d > 38) blinkBehind();

        // the kill: 3 HP = 1.5 hearts, magic damage ignores armor
        if (d <= 2.5 && now >= lastHit) {
            lastHit = now + 20;
            victim.hurt(this.getCommandSenderWorld().damageSources().magic(), 3.0F);
            if (Math.random() < 0.4) say(pick(L_HIT));
        }
    }

    // ------------------------------------------------------------- phases
    /** Called when the player hits him, hits his shell, or notices a slip for long enough. */
    void onPlayerAttacked() {
        if (phase == Phase.OBSERVE) reveal();
    }

    void reveal() {
        if (phase == Phase.CHASE || victim == null) return;
        phase = Phase.CHASE;
        act = null;
        peekPos = null;
        slinkUntil = 0;
        chaseEnd = tickCount + 4 * 60 * 20;
        nextMusic = tickCount;
        nextScream = tickCount;
        nextLine = tickCount + 60;
        lastHit = tickCount + 30;

        if (shell != null) {
            ReplicaMod.SHELLS.remove(shell.getUUID());
            shell.discard();
            shell = null;
        }
        setInvisible(false);
        setGlowingTag(true); // eyes and outline glow in the dark
        if (this.getCommandSenderWorld() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.SMOKE, getX(), getY() + 1.0, getZ(), 40, 0.4, 0.8, 0.4, 0.02);
        }
        setTarget(victim);
        victim.playNotifySound(ReplicaMod.STING.get(), SoundSource.HOSTILE, 1F, 1F);
        say(pick(L_ATTACK).replace("{f}", fearName()));
        setCustomNameVisible(false);
    }

    private void blinkBehind() {
        Vec3 look = victim.getLookAngle();
        double ang = Math.atan2(-look.z, -look.x) + rnd(-0.9F, 0.9F);
        double r = 14 + ThreadLocalRandom.current().nextDouble() * 6;
        double x = victim.getX() + Math.cos(ang) * r;
        double z = victim.getZ() + Math.sin(ang) * r;
        BlockPos top = ((ServerLevel) this.getCommandSenderWorld()).getHeightmapPos(
                Heightmap.Types.MOTION_BLOCKING, new BlockPos(Mth.floor(x), 0, Mth.floor(z)));
        moveTo(x, top.getY(), z, getYRot(), getXRot());
        victim.playNotifySound(SoundEvents.ENDERMAN_TELEPORT, SoundSource.HOSTILE, 1F, 0.8F);
    }

    // ------------------------------------------------------------- helpers
    private boolean lookingAtMe() {
        if (distanceTo(victim) > 22) return false;
        Vec3 look = victim.getLookAngle();
        Vec3 toMe = getEyePosition().subtract(victim.getEyePosition()).normalize();
        return look.dot(toMe) > 0.9;
    }

    private void sampleFear() {
        BlockPos at = victim.blockPosition();
        if (this.getCommandSenderWorld().getMaxLocalRawBrightness(at) < 4) addFear("andhera");
        if (victim.isInWater()) addFear("paani");
        if (victim.getY() > 110 || victim.isFallFlying()) addFear("unchai");
    }

    private void addFear(String key) {
        fear.merge(key, 1, Integer::sum);
    }

    private String fearName() {
        String best = "andhere";
        int score = -1;
        for (Map.Entry<String, Integer> e : fear.entrySet()) {
            if (e.getValue() > score) {
                score = e.getValue();
                best = e.getKey();
            }
        }
        return switch (best) {
            case "paani" -> "paani";
            case "unchai" -> "unchai";
            default -> "andhere";
        };
    }

    private void say(String text) {
        if (victim != null) {
            victim.sendSystemMessage(Component.literal("§7<" + displayName + "> " + text));
        }
    }

    private static int rand(int a, int b) {
        return ThreadLocalRandom.current().nextInt(a, b + 1);
    }

    private static float rnd(float a, float b) {
        return a + ThreadLocalRandom.current().nextFloat() * (b - a);
    }

    private static String pick(String[] arr) {
        return arr[ThreadLocalRandom.current().nextInt(arr.length)];
    }

    @Override
    public void remove(Entity.RemovalReason reason) {
        if (shell != null) {
            ReplicaMod.SHELLS.remove(shell.getUUID());
            shell.discard();
            shell = null;
        }
        if (ReplicaMod.active == this) ReplicaMod.active = null;
        super.remove(reason);
    }
}
